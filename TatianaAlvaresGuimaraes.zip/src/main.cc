#include "headers/cell_tree.h"

Cell::Cell(){
  leftdesc = 0;
  keyw = " ";
  right = nullptr;
  left = nullptr;
}
Cell::Cell(string word){
  leftdesc = 0;
  keyw = word;
  right = nullptr;
  left = nullptr;
}
string Cell::GetValue(){
  return keyw;
}

class BinaryTree{
  protected:
    Cell *root;
    Cell *Find(string keyw);
    Cell *Remove(string keyw);
    void Predecessor(bool right, Cell *par_exc, Cell* &exc);
  public:
    BinaryTree();
    ~BinaryTree();
    Cell *GetRoot();
    void Insert(string neww);
    void Replace(string keyw, string neww);
    void Encript();
    void Decript();
};
BinaryTree::BinaryTree(){
  root = new Cell;
}
BinaryTree::~BinaryTree(){}
Cell *BinaryTree::GetRoot(){
  return root;
}
void BinaryTree::Insert(string neww){
  Cell *aux = root->right, *place = root;
  bool right = true;
  while (aux != nullptr){
    place = aux;
    if (neww < aux->GetValue()){
      aux->leftdesc++;
      aux = aux->left;
      right = false;
    }
    else{
      aux = aux->right;
      right = true;
    }        
  }
  if (right){
    place->right = new Cell(neww);
  }
  else{
    place->left = new Cell(neww);
  }
}
void BinaryTree::Predecessor(bool right, Cell *par_exc, Cell* &exc){
  int code = exc->leftdesc;
  Cell *sub = exc->left, *exc_right = exc->right;
  while(sub->right != nullptr){
    exc = sub;
    sub = sub->right;
  }
  exc->left = sub->left;
  sub->leftdesc = code - 1;
  if(right){
    par_exc->right = sub;
    par_exc->right->right = exc->right;
  }
  else{
    par_exc->left = sub;
    par_exc->left->right = exc->right;
  }
  free(par_exc);
}
Cell *BinaryTree::Remove(string keyw){
  Cell *aux = root->right, *place = root;
  bool right = true;
  while (aux->GetValue() != keyw){
    place = aux;
    if (keyw < aux->GetValue()){
      aux->leftdesc--;
      aux = aux->left;
      right = false;
    }
    else{
      aux = aux->right;
      right = true;
    }        
  }
  if (aux->left == nullptr){
    if (right){
      place->right = aux->right;
    }
    else{
      place->left = aux->right;
    }
    free(aux);
  }
  else if (aux->right == nullptr){
    if (right){
      place->right = aux->left;
    }
    else{
      place->left = aux->left;
    }
    free(aux);
  }
  else{
    this->Predecessor(right, place, aux);
  }
}
void BinaryTree::Replace(string keyw, string neww){
  this->Remove(keyw);
  this->Insert(neww);
}
void BinaryTree::Encript(){
  int sizem, code;
  string wrd, mess = "";
  Cell *aux;
  cin >> sizem;
  for(int i = 0; i < sizem; i++){
    cin >> wrd;
    aux = root->right;
    code = 1;
    while(aux->GetValue() != wrd){
      code++;
      if(wrd < aux->GetValue()){
        aux = aux->left;
      }
      else{
        code = code + aux->leftdesc;
        aux = aux->right;
      }
    }
    mess = mess + to_string(code) + " ";
  }
  cout << mess << "\n";
}
void BinaryTree::Decript(){
  int sizem, key;
  string mess = "";
  Cell *aux;
  cin >> sizem;
  for(int i = 0; i < sizem; i++){
    cin >> key;
    aux = root->right;
    while(key > 1){
      key--;
      if(key <= aux->leftdesc){
        aux = aux->left;
      }
      else{
        key = key - aux->leftdesc;
        aux = aux->right;
      }
    }
    mess = mess + aux->GetValue() + " ";
  }
  cout << mess << "\n";
}
bool Action(char command, BinaryTree *tree){
  switch (command) {
    case 'i': {
      string newword;
      cin >> newword;
      tree->Insert(newword);
      return true;
    }
    case 'e': {
      tree->Encript();
      return true;
    } 
    case 'd': {
      tree->Decript();
      return true;
    }  
    case 's': {
      string oldword, newword;
      cin >> oldword >> newword;
      tree->Replace(oldword, newword);
      return true;
    }
    default:
      return false;
  }
}

int main() {
  BinaryTree dictio; 
  char command;
  do {
    cin >> command;
  } while (Action(command, &dictio));
  return 0;
}