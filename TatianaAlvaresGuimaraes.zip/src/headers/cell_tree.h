#include <iostream>
#include <string>
using namespace std;

class Cell{
  protected:
    string keyw;
  public:
    int leftdesc;
    Cell *right, *left;
    Cell();
    Cell(string word);
    ~Cell();
    string GetValue();
};
class BinaryTree{
  protected:
    Cell *root;
    Cell *Find(string keyw);
    Cell *Remove(string keyw);
    void Predecessor(bool right, Cell *par_exc, Cell* &exc);
  public:
    BinaryTree();
    ~BinaryTree();
    Cell *GetRoot();
    void Insert(string neww);
    void Replace(string keyw, string neww);
    void Encript();
    void Decript();
};